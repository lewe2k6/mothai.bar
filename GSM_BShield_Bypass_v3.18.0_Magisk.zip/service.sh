#!/system/bin/sh
MODDIR=${0%/*}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done
sleep 3

clean_bshield_flags() {
  # 1. Khóa lại toàn bộ thuộc tính Bootloader & Custom ROM
  resetprop -n ro.boot.verifiedbootstate green 2>/dev/null
  resetprop -n vendor.boot.verifiedbootstate green 2>/dev/null
  resetprop -n ro.boot.flash.locked 1 2>/dev/null
  resetprop -n ro.boot.vbmeta.device_state locked 2>/dev/null
  resetprop -n vendor.boot.vbmeta.device_state locked 2>/dev/null
  resetprop -n ro.boot.veritymode enforcing 2>/dev/null
  resetprop -n ro.boot.warranty_bit 0 2>/dev/null
  resetprop -n ro.warranty_bit 0 2>/dev/null
  resetprop -n sys.oem_unlock_allowed 0 2>/dev/null
  resetprop -n ro.debuggable 0 2>/dev/null
  resetprop -n ro.secure 1 2>/dev/null
  resetprop -n ro.adb.secure 1 2>/dev/null
  resetprop -n ro.build.type user 2>/dev/null
  resetprop -n ro.build.tags release-keys 2>/dev/null
  resetprop -n init.svc.adbd stopped 2>/dev/null
  resetprop -n persist.adb.tls_server.enable 0 2>/dev/null
  resetprop -n service.adb.tcp.port -1 2>/dev/null

  # 2. Bypass Bit 10 (is_adb_enabled) & Bit 11 (is_developer_options_enabled)
  settings put global development_settings_enabled 0 2>/dev/null
  settings put global adb_enabled 0 2>/dev/null
  settings put global adb_wifi_enabled 0 2>/dev/null
  settings put secure development_settings_enabled 0 2>/dev/null
  settings put secure adb_enabled 0 2>/dev/null
  settings put secure adb_wifi_enabled 0 2>/dev/null

  # 3. Bypass Bit 14 (is_unknown_sources_enabled)
  settings put secure install_non_market_apps 0 2>/dev/null
  settings put global install_non_market_apps 0 2>/dev/null

  # 4. Bypass Bit 19 (is_system_proxy)
  settings put global http_proxy :0 2>/dev/null
  settings delete global http_proxy 2>/dev/null
  settings delete global global_http_proxy_host 2>/dev/null
  settings delete global global_http_proxy_port 2>/dev/null
  settings delete global global_http_proxy_exclusion_list 2>/dev/null

  # 5. Bypass Mock Location & Accessibility check (Lhgtd/ssde & RmsV2$HeartbeatData)
  settings put secure mock_location 0 2>/dev/null
  settings put secure accessibility_enabled 0 2>/dev/null
  settings put secure enabled_accessibility_services "" 2>/dev/null

  # 6. Đặt nguồn cài đặt (Installer Package) thành Google Play Store (com.android.vending)
  if pm list packages 2>/dev/null | grep -q "net.gsm.driver.app"; then
    pm set-installer net.gsm.driver.app com.android.vending 2>/dev/null
    cmd package set-installer net.gsm.driver.app com.android.vending 2>/dev/null
  fi
}

# Đồng bộ cấu hình Magisk DenyList cho Magisk 30700
if command -v magisk >/dev/null 2>&1; then
  magisk --denylist add net.gsm.driver.app 2>/dev/null
  magisk --denylist add net.gsm.driver.app net.gsm.driver.app 2>/dev/null
  magisk --denylist add net.gsm.driver.app net.gsm.driver.app:dgis 2>/dev/null
  magisk --denylist add com.google.android.gms com.google.android.gms.unstable 2>/dev/null
  if [ -d /data/adb/modules/zygisk_shamiko ] || [ -d /data/adb/modules/zygisk-assistant ] || [ -d /data/adb/modules/nohello ]; then
    magisk --denylist disable 2>/dev/null
  else
    magisk --denylist enable 2>/dev/null
  fi
fi

# Đảm bảo khi vừa khởi động lên thì unhide Magisk nếu lần trước tắt máy đột ngột
pm unhide com.topjohnwu.magisk 2>/dev/null

# Làm sạch cờ ngay khi máy khởi động xong
clean_bshield_flags

# Daemon canh tiến trình net.gsm.driver.app:
# - Ngay khi mở Green SM Driver: tự động dọn sạch cờ + tự động `pm hide com.topjohnwu.magisk`
#   (để cả khi bạn không có nút Ẩn ứng dụng Magisk, BShield vẫn không bao giờ tìm thấy gói Magisk!)
# - Ngay khi đóng/vuốt tắt Green SM Driver: tự động `pm unhide com.topjohnwu.magisk` để hiện lại icon Magisk!
WAS_RUNNING=0
MAGISK_HIDDEN_BY_US=0
while true; do
  if pidof net.gsm.driver.app >/dev/null 2>&1; then
    if [ "$WAS_RUNNING" = "0" ]; then
      clean_bshield_flags
      if pm list packages 2>/dev/null | grep -q "com.topjohnwu.magisk"; then
        pm hide com.topjohnwu.magisk 2>/dev/null
        MAGISK_HIDDEN_BY_US=1
      fi
      WAS_RUNNING=1
    else
      DEV_OPT=$(settings get global development_settings_enabled 2>/dev/null)
      ADB_OPT=$(settings get global adb_enabled 2>/dev/null)
      WIFI_ADB=$(settings get global adb_wifi_enabled 2>/dev/null)
      ACC_OPT=$(settings get secure accessibility_enabled 2>/dev/null)
      if [ "$DEV_OPT" = "1" ] || [ "$ADB_OPT" = "1" ] || [ "$WIFI_ADB" = "1" ] || [ "$ACC_OPT" = "1" ]; then
        clean_bshield_flags
      fi
    fi
  else
    if [ "$WAS_RUNNING" = "1" ]; then
      if [ "$MAGISK_HIDDEN_BY_US" = "1" ]; then
        pm unhide com.topjohnwu.magisk 2>/dev/null
        MAGISK_HIDDEN_BY_US=0
      fi
      WAS_RUNNING=0
    fi
  fi
  sleep 1
done
