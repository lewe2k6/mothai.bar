#!/system/bin/sh
MODDIR=${0%/*}

sprop() {
  resetprop -n "$1" "$2" 2>/dev/null
}

# 1. Bypass Bit 6 (is_bootloader_unlocked) & FPT eKYC (libnative-lib.so: ro.boot.verifiedbootstate)
sprop ro.boot.verifiedbootstate green
sprop vendor.boot.verifiedbootstate green
sprop ro.boot.flash.locked 1
sprop ro.boot.vbmeta.device_state locked
sprop vendor.boot.vbmeta.device_state locked
sprop ro.boot.veritymode enforcing
sprop ro.boot.vbmeta.avb_version 1.2
sprop ro.boot.warranty_bit 0
sprop ro.warranty_bit 0
sprop ro.boot.realme.lockstate 1
sprop vendor.boot.realme.lockstate 1
sprop sys.oem_unlock_allowed 0
sprop ro.oem_unlock_supported 0

# 2. Bypass Bit 12 (is_custom_rom) & Debuggable/Secure props
sprop ro.debuggable 0
sprop ro.secure 1
sprop ro.adb.secure 1
sprop ro.build.selinux 1

for part in "" "system." "vendor." "product." "odm." "system_ext." "vendor_dlkm." "system_dlkm." "bootimage."; do
  sprop "ro.${part}build.type" user
  sprop "ro.${part}build.tags" release-keys
done

# Làm sạch chuỗi test-keys / dev-keys / userdebug / lineage / aosp trong fingerprint & description
for prop in ro.build.description ro.build.display.id ro.build.flavor; do
  VAL=$(getprop "$prop")
  case "$VAL" in
    *test-keys*|*dev-keys*|*userdebug*|*lineage_*|*aosp_*)
      CLEAN_VAL=$(echo "$VAL" | sed 's/test-keys/release-keys/g; s/dev-keys/release-keys/g; s/userdebug/user/g; s/lineage_//g; s/aosp_//g')
      sprop "$prop" "$CLEAN_VAL"
      ;;
  esac
done

for prop in ro.build.fingerprint ro.system.build.fingerprint ro.vendor.build.fingerprint ro.product.build.fingerprint ro.odm.build.fingerprint; do
  FP=$(getprop "$prop")
  case "$FP" in
    *test-keys*|*dev-keys*|*userdebug*)
      CLEAN_FP=$(echo "$FP" | sed 's/test-keys/release-keys/g; s/dev-keys/release-keys/g; s/userdebug/user/g')
      sprop "$prop" "$CLEAN_FP"
      ;;
  esac
done

# 3. Ẩn trạng thái adbd & USB debugging ở tầng property
sprop init.svc.adbd stopped
sprop init.svc.adbd_wifi stopped
sprop service.adb.tcp.port -1
sprop persist.adb.tls_server.enable 0
sprop sys.usb.state mtp
sprop sys.usb.config mtp
sprop persist.sys.usb.config mtp

# 4. Hạn chế rò rỉ thông tin kernel cho tiến trình thường (libsiuzm.so / libvkauxj.so)
echo 2 > /proc/sys/kernel/kptr_restrict 2>/dev/null
echo 1 > /proc/sys/kernel/dmesg_restrict 2>/dev/null
chmod 0440 /proc/net/unix 2>/dev/null
