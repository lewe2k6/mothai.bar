#!/system/bin/sh
MODDIR=${0%/*}

echo "================================================"
echo "  KIỂM TRA & DỌN SẠCH 13 CỜ BSHIELD (v3.18.0)   "
echo "================================================"

# Dọn sạch toàn bộ cờ ngay lập tức
resetprop -n ro.boot.verifiedbootstate green 2>/dev/null
resetprop -n vendor.boot.verifiedbootstate green 2>/dev/null
resetprop -n ro.boot.flash.locked 1 2>/dev/null
resetprop -n ro.boot.vbmeta.device_state locked 2>/dev/null
resetprop -n vendor.boot.vbmeta.device_state locked 2>/dev/null
resetprop -n ro.boot.veritymode enforcing 2>/dev/null
resetprop -n ro.boot.warranty_bit 0 2>/dev/null
resetprop -n ro.warranty_bit 0 2>/dev/null
resetprop -n sys.oem_unlock_allowed 0 2>/dev/null
resetprop -n ro.debuggable 0 2>/dev/null
resetprop -n ro.secure 1 2>/dev/null
resetprop -n ro.adb.secure 1 2>/dev/null
resetprop -n ro.build.type user 2>/dev/null
resetprop -n ro.build.tags release-keys 2>/dev/null
resetprop -n init.svc.adbd stopped 2>/dev/null
resetprop -n persist.adb.tls_server.enable 0 2>/dev/null
resetprop -n service.adb.tcp.port -1 2>/dev/null

settings put global development_settings_enabled 0 2>/dev/null
settings put global adb_enabled 0 2>/dev/null
settings put global adb_wifi_enabled 0 2>/dev/null
settings put secure development_settings_enabled 0 2>/dev/null
settings put secure adb_enabled 0 2>/dev/null
settings put secure adb_wifi_enabled 0 2>/dev/null
settings put secure install_non_market_apps 0 2>/dev/null
settings put global install_non_market_apps 0 2>/dev/null
settings put secure mock_location 0 2>/dev/null
settings put secure accessibility_enabled 0 2>/dev/null
settings put secure enabled_accessibility_services "" 2>/dev/null
settings put global http_proxy :0 2>/dev/null
settings delete global http_proxy 2>/dev/null
settings delete global global_http_proxy_host 2>/dev/null
settings delete global global_http_proxy_port 2>/dev/null

if command -v magisk >/dev/null 2>&1; then
  magisk --denylist add net.gsm.driver.app 2>/dev/null
  magisk --denylist add net.gsm.driver.app net.gsm.driver.app 2>/dev/null
  magisk --denylist add net.gsm.driver.app net.gsm.driver.app:dgis 2>/dev/null
  magisk --denylist add com.google.android.gms com.google.android.gms.unstable 2>/dev/null
  if [ -d /data/adb/modules/zygisk_shamiko ] || [ -d /data/adb/modules/zygisk-assistant ] || [ -d /data/adb/modules/nohello ]; then
    magisk --denylist disable 2>/dev/null
  else
    magisk --denylist enable 2>/dev/null
  fi
fi

if pm list packages 2>/dev/null | grep -q "net.gsm.driver.app"; then
  pm set-installer net.gsm.driver.app com.android.vending 2>/dev/null
  cmd package set-installer net.gsm.driver.app com.android.vending 2>/dev/null
fi

echo "[1] Bit 6 (is_bootloader_unlocked):"
echo "    verifiedbootstate = $(getprop ro.boot.verifiedbootstate) | flash.locked = $(getprop ro.boot.flash.locked) -> [OK]"

echo "[2] Bit 12 (is_custom_rom):"
echo "    build.tags = $(getprop ro.build.tags) | build.type = $(getprop ro.build.type) -> [OK]"

echo "[3] Bit 11 (is_developer_options_enabled):"
echo "    development_settings_enabled = $(settings get global development_settings_enabled) -> [OK]"

echo "[4] Bit 10 (is_adb_enabled):"
echo "    adb_enabled = $(settings get global adb_enabled) | adb_wifi = $(settings get global adb_wifi_enabled) -> [OK]"

echo "[5] Bit 14 (is_unknown_sources_enabled):"
echo "    install_non_market_apps = $(settings get secure install_non_market_apps) -> [OK]"

echo "[6] Nguồn cài đặt Google Play (com.android.vending):"
INST=$(pm list packages -i net.gsm.driver.app 2>/dev/null)
echo "    $INST -> [OK]"

echo "[7] Bit 15 (is_blacklisted_app_detected):"
if pm list packages 2>/dev/null | grep -q "com.topjohnwu.magisk"; then
  echo "    Phát hiện com.topjohnwu.magisk -> Module sẽ TỰ ĐỘNG 'pm hide'"
  echo "    gói này mỗi khi bạn mở Green SM Driver và hiện lại khi đóng! -> [OK]"
else
  echo "    App Magisk đã đổi tên gói (không còn com.topjohnwu.magisk) -> [OK]"
fi

echo "[8] Bit 23 (is_vpn) & Bit 19 (is_system_proxy):"
if ip link 2>/dev/null | grep -E -q "tun[0-9]|ppp[0-9]|wg[0-9]"; then
  echo "    [CẢNH BÁO] Phát hiện VPN đang bật! Hãy tắt VPN trước khi mở app!"
else
  echo "    Không có VPN & Proxy -> [OK]"
fi

echo "================================================"
echo "  ĐÃ DỌN SẠCH CỜ! BẠN CÓ THỂ MỞ GREEN SM NGAY!  "
echo "================================================"
