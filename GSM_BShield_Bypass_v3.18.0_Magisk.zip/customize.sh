SKIPUNZIP=0

ui_print "================================================"
ui_print "   GREEN SM DRIVER v3.18.0 - BSHIELD BYPASS     "
ui_print "   Target: net.gsm.driver.app (verCode 438)     "
ui_print "   Tối ưu cho Magisk 30700 / App 31100 (r3)     "
ui_print "================================================"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755

ui_print "[+] Đang cấu hình Magisk DenyList cho Green SM Driver..."
if command -v magisk >/dev/null 2>&1; then
  magisk --denylist add net.gsm.driver.app 2>/dev/null
  magisk --denylist add net.gsm.driver.app net.gsm.driver.app 2>/dev/null
  magisk --denylist add net.gsm.driver.app net.gsm.driver.app:dgis 2>/dev/null
  magisk --denylist add com.google.android.gms com.google.android.gms.unstable 2>/dev/null
  if [ -d /data/adb/modules/zygisk_shamiko ] || [ -d /data/adb/modules/zygisk-assistant ] || [ -d /data/adb/modules/nohello ]; then
    ui_print "[+] Phát hiện module ẩn Zygisk (Shamiko/Assistant/NoHello)"
    ui_print "    -> Giữ Enforce DenyList = OFF để module ẩn hoạt động chuẩn"
    magisk --denylist disable 2>/dev/null
  else
    ui_print "[+] Bật Enforce DenyList mặc định của Magisk 30700"
    magisk --denylist enable 2>/dev/null
  fi
fi

if pm list packages 2>/dev/null | grep -q "net.gsm.driver.app"; then
  ui_print "[+] Đặt nguồn cài đặt Green SM Driver -> Google Play Store (com.android.vending)..."
  pm set-installer net.gsm.driver.app com.android.vending 2>/dev/null
  cmd package set-installer net.gsm.driver.app com.android.vending 2>/dev/null
fi

ui_print "[+] Bật tính năng tự động ẩn gói Magisk (pm hide) mỗi khi mở Green SM Driver"
ui_print "    và tự động hiện lại (pm unhide) khi đóng Green SM Driver!"
ui_print "================================================"
